/**
 * API 配置
 * - Web 部署时：使用相对路径（同源）
 * - 开发环境：使用环境变量 EXPO_PUBLIC_BACKEND_BASE_URL
 */
const getApiBase = () => {
  // 检查是否在 Web 环境且同源部署
  if (typeof window !== 'undefined' && window.location) {
    // 如果是 Web 环境，使用相对路径
    return '/api/v1';
  }
  // 否则使用环境变量（原生 App 或开发环境）
  return `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL || ''}/api/v1`;
};

export const API_BASE = getApiBase();

export const getFullApiUrl = (path: string) => {
  return `${API_BASE}${path}`;
};
