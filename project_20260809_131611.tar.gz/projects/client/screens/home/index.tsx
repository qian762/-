import { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';

const API_BASE = typeof window !== 'undefined' ? '/api/v1' : `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL || ''}/api/v1`;

interface Category {
  id: number;
  name: string;
  icon: string;
  sort_order: number;
  is_preset: boolean;
}

const ICON_OPTIONS = [
  'Bed', 'Armchair', 'Warehouse', 'Tv', 'Table',
  'Lamp', 'DoorOpen', 'Couch', 'Chair', 'BasketShopping',
];

export default function HomeScreen() {
  const router = useSafeRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Home');
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null);

  const fetchCategories = useCallback(async () => {
    try {
      /**
       * 服务端文件：server/src/routes/categories.ts
       * 接口：GET /api/v1/categories
       * 无参数
       */
      const response = await fetch(`${API_BASE}/categories`);
      const data = await response.json();
      setCategories(data);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchCategories();
    }, [fetchCategories])
  );

  const handleAddCategory = async () => {
    if (!newName.trim()) {
      Alert.alert('提示', '请输入分类名称');
      return;
    }
    try {
      /**
       * 服务端文件：server/src/routes/categories.ts
       * 接口：POST /api/v1/categories
       * Body 参数：name: string, icon: string
       */
      const response = await fetch(`${API_BASE}/categories`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim(), icon: selectedIcon }),
      });
      if (!response.ok) throw new Error('Failed to create');
      setModalVisible(false);
      setNewName('');
      setSelectedIcon('Home');
      fetchCategories();
    } catch (err) {
      Alert.alert('错误', '创建分类失败');
    }
  };

  const handleDeleteCategory = async () => {
    if (!deleteTarget) return;
    try {
      /**
       * 服务端文件：server/src/routes/categories.ts
       * 接口：DELETE /api/v1/categories/:id
       * Path 参数：id: number
       */
      const response = await fetch(`${API_BASE}/categories/${deleteTarget.id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete');
      setDeleteTarget(null);
      fetchCategories();
    } catch (err) {
      Alert.alert('错误', '删除分类失败');
    }
  };

  const getIconComponent = (iconName: string) => {
    const iconMap: Record<string, React.ComponentProps<typeof FontAwesome6>['name']> = {
      Bed: 'bed',
      Armchair: 'couch',
      Warehouse: 'warehouse',
      Tv: 'tv',
      Table: 'table',
      Lamp: 'lamp',
      DoorOpen: 'door-open',
      Couch: 'couch',
      Chair: 'chair',
      BasketShopping: 'basket-shopping',
      Home: 'home',
    };
    return iconMap[iconName] || 'home';
  };

  const renderCategoryCard = ({ item }: { item: Category }) => (
    <View style={styles.cardWrapper}>
      <TouchableOpacity
        style={styles.categoryCard}
        activeOpacity={0.7}
        onPress={() => router.push('/styles-list', { categoryId: item.id, categoryName: item.name })}
      >
        <View style={styles.iconContainer}>
          <FontAwesome6 name={getIconComponent(item.icon)} size={28} color="#8B6F47" />
        </View>
        <Text style={styles.categoryName}>{item.name}</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={(e) => {
          if (Platform.OS === 'web') {
            e.stopPropagation();
          }
          setDeleteTarget(item);
        }}
        hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
      >
        <FontAwesome6 name="trash-can" size={14} color="#C0B8B0" />
      </TouchableOpacity>
    </View>
  );

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>家具分类</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
          <FontAwesome6 name="plus" size={18} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {categories.length === 0 ? (
        <View style={styles.emptyContainer}>
          <FontAwesome6 name="box-open" size={48} color="#B5ADA5" />
          <Text style={styles.emptyText}>暂无分类</Text>
          <Text style={styles.emptySubText}>点击右上角 + 添加分类</Text>
        </View>
      ) : (
        <FlatList
          data={categories}
          renderItem={renderCategoryCard}
          keyExtractor={(item) => item.id.toString()}
          numColumns={2}
          contentContainerStyle={styles.listContent}
          columnWrapperStyle={styles.row}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* 添加分类 Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>添加分类</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <FontAwesome6 name="xmark" size={20} color="#8B8680" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <Text style={styles.label}>分类名称</Text>
              <TextInput
                style={styles.input}
                placeholder="例如：书架、餐桌..."
                placeholderTextColor="#B5ADA5"
                value={newName}
                onChangeText={setNewName}
              />

              <Text style={styles.label}>选择图标</Text>
              <View style={styles.iconGrid}>
                {ICON_OPTIONS.map((icon) => (
                  <TouchableOpacity
                    key={icon}
                    style={[styles.iconOption, selectedIcon === icon && styles.iconOptionSelected]}
                    onPress={() => setSelectedIcon(icon)}
                  >
                    <FontAwesome6
                      name={getIconComponent(icon)}
                      size={22}
                      color={selectedIcon === icon ? '#8B6F47' : '#8B8680'}
                    />
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.submitButton]}
                onPress={handleAddCategory}
              >
                <Text style={styles.submitButtonText}>确定</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 删除确认 Modal */}
      <Modal visible={deleteTarget !== null} transparent animationType="fade">
        <TouchableOpacity
          style={styles.confirmOverlay}
          activeOpacity={1}
          onPress={() => setDeleteTarget(null)}
        >
          <View style={styles.confirmBox}>
            <Text style={styles.confirmTitle}>确认删除</Text>
            <Text style={styles.confirmMessage}>
              将同时删除「{deleteTarget?.name}」下所有风格和照片，确定删除吗？
            </Text>
            <View style={styles.confirmButtons}>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmCancelButton]}
                onPress={() => setDeleteTarget(null)}
              >
                <Text style={styles.confirmCancelText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmDeleteButton]}
                onPress={handleDeleteCategory}
              >
                <Text style={styles.confirmDeleteText}>删除</Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 28, fontWeight: '700', color: '#2C2420' },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#8B6F47',
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: { paddingHorizontal: 16, paddingBottom: 20 },
  row: { justifyContent: 'space-between', marginBottom: 16 },
  cardWrapper: {
    width: '47%',
    position: 'relative',
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    shadowColor: 'rgba(139, 111, 71, 0.08)',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 4,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(139, 111, 71, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryName: { fontSize: 16, fontWeight: '600', color: '#2C2420' },
  deleteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    padding: 8,
    zIndex: 10,
  },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { fontSize: 18, fontWeight: '600', color: '#8B8680', marginTop: 16 },
  emptySubText: { fontSize: 14, color: '#B5ADA5', marginTop: 8 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 32,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 0, 0, 0.05)',
  },
  modalTitle: { fontSize: 20, fontWeight: '700', color: '#2C2420' },
  modalBody: { padding: 20 },
  label: { fontSize: 15, fontWeight: '600', color: '#2C2420', marginBottom: 8 },
  input: {
    backgroundColor: 'rgba(0, 0, 0, 0.04)',
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    color: '#2C2420',
    marginBottom: 20,
  },
  iconGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  iconOption: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.04)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconOptionSelected: {
    backgroundColor: 'rgba(139, 111, 71, 0.15)',
    borderWidth: 2,
    borderColor: '#8B6F47',
  },
  modalFooter: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
    marginTop: 8,
  },
  modalButton: { flex: 1, padding: 16, borderRadius: 12, alignItems: 'center' },
  cancelButton: { backgroundColor: 'rgba(0, 0, 0, 0.06)' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#8B8680' },
  submitButton: { backgroundColor: '#8B6F47' },
  submitButtonText: { fontSize: 16, fontWeight: '600', color: '#FFFFFF' },
  // 删除确认弹窗样式
  confirmOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmBox: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '80%',
    maxWidth: 320,
  },
  confirmTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2C2420',
    marginBottom: 12,
    textAlign: 'center',
  },
  confirmMessage: {
    fontSize: 15,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  confirmButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  confirmButton: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmCancelButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.06)',
  },
  confirmCancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#8B8680',
  },
  confirmDeleteButton: {
    backgroundColor: '#D45D5D',
  },
  confirmDeleteText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});
