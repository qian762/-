import { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  Platform,
} from 'react-native';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import { useSafeRouter, useSafeSearchParams } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';

const API_BASE = `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1`;

interface StyleItem {
  id: number;
  name: string;
  photo_count: number;
  created_at: string;
}

export default function StylesListScreen() {
  const router = useSafeRouter();
  const { categoryId, categoryName } = useSafeSearchParams<{ categoryId: number; categoryName: string }>();
  const [styleList, setStyleList] = useState<StyleItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [newName, setNewName] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<StyleItem | null>(null);

  const fetchStyles = useCallback(async () => {
    try {
      /**
       * 服务端文件：server/src/routes/styles.ts
       * 接口：GET /api/v1/categories/:categoryId/styles
       * Path 参数：categoryId: number
       */
      const response = await fetch(`${API_BASE}/categories/${categoryId}/styles`);
      const data = await response.json();
      setStyleList(data);
    } catch (err) {
      console.error('Failed to fetch styles:', err);
    } finally {
      setLoading(false);
    }
  }, [categoryId]);

  useFocusEffect(
    useCallback(() => {
      fetchStyles();
    }, [fetchStyles])
  );

  const handleAddStyle = async () => {
    if (!newName.trim()) {
      Alert.alert('提示', '请输入风格名称');
      return;
    }
    try {
      /**
       * 服务端文件：server/src/routes/styles.ts
       * 接口：POST /api/v1/styles
       * Body 参数：name: string, category_id: number
       */
      const response = await fetch(`${API_BASE}/styles`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName.trim(), category_id: Number(categoryId) }),
      });
      if (!response.ok) throw new Error('Failed to create');
      setModalVisible(false);
      setNewName('');
      fetchStyles();
    } catch (err) {
      Alert.alert('错误', '创建风格失败');
    }
  };

  const handleDeleteStyle = async () => {
    if (!deleteTarget) return;
    try {
      /**
       * 服务端文件：server/src/routes/styles.ts
       * 接口：DELETE /api/v1/styles/:id
       * Path 参数：id: number
       */
      const response = await fetch(`${API_BASE}/styles/${deleteTarget.id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete');
      setDeleteTarget(null);
      fetchStyles();
    } catch (err) {
      Alert.alert('错误', '删除风格失败');
    }
  };

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.canGoBack() ? router.back() : router.replace('/')} style={styles.backButton}>
          <FontAwesome6 name="chevron-left" size={20} color="#2C2420" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{categoryName}</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
          <FontAwesome6 name="plus" size={16} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {styleList.length === 0 ? (
        <View style={styles.emptyContainer}>
          <FontAwesome6 name="palette" size={48} color="#B5ADA5" />
          <Text style={styles.emptyText}>暂无风格</Text>
          <Text style={styles.emptySubText}>点击右上角 + 添加风格</Text>
        </View>
      ) : (
        <FlatList
          data={styleList}
          renderItem={({ item }) => (
            <View style={styles.styleCardWrapper}>
              <TouchableOpacity
                style={styles.styleCard}
                activeOpacity={0.7}
                onPress={() =>
                  router.push('/photos', { styleId: item.id, styleName: item.name })
                }
              >
                <View style={styles.styleInfo}>
                  <Text style={styles.styleName}>{item.name}</Text>
                  <Text style={styles.photoCount}>{item.photo_count} 张照片</Text>
                </View>
                <FontAwesome6 name="chevron-right" size={16} color="#B5ADA5" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={(e) => {
                  if (Platform.OS === 'web') {
                    e.stopPropagation();
                  }
                  setDeleteTarget(item);
                }}
                hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
              >
                <FontAwesome6 name="trash-can" size={14} color="#C0B8B0" />
              </TouchableOpacity>
            </View>
          )}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* 添加风格 Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>添加风格</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <FontAwesome6 name="xmark" size={20} color="#8B8680" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <Text style={styles.label}>风格名称</Text>
              <TextInput
                style={styles.input}
                placeholder="例如：现代简约、北欧风..."
                placeholderTextColor="#B5ADA5"
                value={newName}
                onChangeText={setNewName}
              />
            </View>

            <View style={styles.modalFooter}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.submitButton]}
                onPress={handleAddStyle}
              >
                <Text style={styles.submitButtonText}>确定</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 删除确认 Modal */}
      <Modal visible={deleteTarget !== null} transparent animationType="fade">
        <TouchableOpacity
          style={styles.confirmOverlay}
          activeOpacity={1}
          onPress={() => setDeleteTarget(null)}
        >
          <View style={styles.confirmBox}>
            <Text style={styles.confirmTitle}>确认删除</Text>
            <Text style={styles.confirmMessage}>
              将同时删除「{deleteTarget?.name}」下所有照片，确定删除吗？
            </Text>
            <View style={styles.confirmButtons}>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmCancelButton]}
                onPress={() => setDeleteTarget(null)}
              >
                <Text style={styles.confirmCancelText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.confirmButton, styles.confirmDeleteButton]}
                onPress={handleDeleteStyle}
              >
                <Text style={styles.confirmDeleteText}>删除</Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerTitle: { flex: 1, fontSize: 22, fontWeight: '700', color: '#2C2420', marginLeft: 8 },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#8B6F47',
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContent: { paddingHorizontal: 16, paddingTop: 8 },
  styleCardWrapper: {
    position: 'relative',
    marginBottom: 12,
  },
  styleCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 18,
    paddingRight: 44,
    shadowColor: 'rgba(139, 111, 71, 0.06)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 2,
  },
  deleteButton: {
    position: 'absolute',
    right: 12,
    top: '50%',
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(250, 247, 242, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  styleInfo: { flex: 1 },
  styleName: { fontSize: 16, fontWeight: '600', color: '#2C2420', marginBottom: 4 },
  photoCount: { fontSize: 13, color: '#8B8680' },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  emptyText: { fontSize: 16, color: '#8B8680', marginTop: 16 },
  emptySubText: { fontSize: 13, color: '#B5ADA5', marginTop: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'flex-end' },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: 34,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E0D8',
  },
  modalTitle: { fontSize: 18, fontWeight: '600', color: '#2C2420' },
  modalBody: { paddingHorizontal: 20, paddingTop: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#2C2420', marginBottom: 8 },
  input: {
    backgroundColor: '#F5F0EB',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 15,
    color: '#2C2420',
  },
  modalFooter: { flexDirection: 'row', paddingHorizontal: 20, paddingTop: 20, gap: 12 },
  modalButton: { flex: 1, paddingVertical: 14, borderRadius: 9999, alignItems: 'center' },
  cancelButton: { backgroundColor: '#F5F0EB' },
  cancelButtonText: { fontSize: 16, fontWeight: '600', color: '#8B8680' },
  submitButton: { backgroundColor: '#8B6F47' },
  submitButtonText: { fontSize: 16, fontWeight: '600', color: '#FFFFFF' },
  // 删除确认弹窗样式
  confirmOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  confirmBox: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    width: '80%',
    maxWidth: 320,
  },
  confirmTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#2C2420',
    marginBottom: 12,
    textAlign: 'center',
  },
  confirmMessage: {
    fontSize: 15,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 22,
  },
  confirmButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  confirmButton: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmCancelButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.06)',
  },
  confirmCancelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#8B8680',
  },
  confirmDeleteButton: {
    backgroundColor: '#D45D5D',
  },
  confirmDeleteText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});
