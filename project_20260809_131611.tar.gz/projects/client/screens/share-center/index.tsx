import { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Image,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';

const API_BASE = `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1`;
const SCREEN_WIDTH = Dimensions.get('window').width;
const GRID_GAP = 4;
const PHOTO_SIZE = (SCREEN_WIDTH - GRID_GAP * 4) / 3;

interface SharedPhoto {
  id: number;
  image_url: string;
}

interface ShareItem {
  id: number;
  share_token: string;
  style_name: string;
  category_name: string;
  created_at: string;
  expired_at: string;
  is_expired: boolean;
  photo_count: number;
  cover_url?: string;
}

export default function ShareCenterScreen() {
  const router = useSafeRouter();
  const [shares, setShares] = useState<ShareItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchShares = useCallback(async () => {
    try {
      /**
       * 服务端文件：server/src/routes/shares.ts
       * 接口：GET /api/v1/shares
       * 无参数
       */
      const response = await fetch(`${API_BASE}/shares`);
      const data = await response.json();
      setShares(data);
    } catch (err) {
      console.error('Failed to fetch shares:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchShares();
    }, [fetchShares])
  );

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return `${date.getMonth() + 1}/${date.getDate()} ${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>分享中心</Text>
      </View>

      {shares.length === 0 ? (
        <View style={styles.emptyContainer}>
          <FontAwesome6 name="share-nodes" size={48} color="#B5ADA5" />
          <Text style={styles.emptyText}>暂无分享</Text>
          <Text style={styles.emptySubText}>在照片页面创建分享链接</Text>
        </View>
      ) : (
        <FlatList
          data={shares}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.shareCard}
              activeOpacity={0.7}
              onPress={() =>
                router.push('/share-view', { token: item.share_token })
              }
            >
              {item.cover_url ? (
                <Image source={{ uri: item.cover_url }} style={styles.coverImage} />
              ) : (
                <View style={styles.coverPlaceholder}>
                  <FontAwesome6 name="images" size={24} color="#B5ADA5" />
                </View>
              )}
              <View style={styles.shareInfo}>
                <Text style={styles.shareTitle}>{item.style_name}</Text>
                <Text style={styles.shareSubtitle}>{item.category_name}</Text>
                <View style={styles.shareMeta}>
                  <Text style={styles.shareDate}>{formatDate(item.created_at)}</Text>
                  {item.is_expired ? (
                    <Text style={styles.expiredBadge}>已过期</Text>
                  ) : (
                    <Text style={styles.activeBadge}>有效</Text>
                  )}
                </View>
              </View>
              <FontAwesome6 name="chevron-right" size={16} color="#B5ADA5" />
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 28, fontWeight: '700', color: '#2C2420' },
  listContent: { paddingHorizontal: 16, paddingTop: 8 },
  shareCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    shadowColor: 'rgba(139, 111, 71, 0.06)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 2,
  },
  coverImage: { width: 56, height: 56, borderRadius: 10, backgroundColor: '#F5F0EB' },
  coverPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 10,
    backgroundColor: '#F5F0EB',
    justifyContent: 'center',
    alignItems: 'center',
  },
  shareInfo: { flex: 1, marginLeft: 12 },
  shareTitle: { fontSize: 15, fontWeight: '600', color: '#2C2420', marginBottom: 2 },
  shareSubtitle: { fontSize: 12, color: '#8B8680', marginBottom: 4 },
  shareMeta: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  shareDate: { fontSize: 11, color: '#B5ADA5' },
  expiredBadge: {
    fontSize: 10,
    color: '#D45D5D',
    backgroundColor: 'rgba(212, 93, 93, 0.1)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  activeBadge: {
    fontSize: 10,
    color: '#059669',
    backgroundColor: 'rgba(5, 150, 105, 0.1)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  emptyText: { fontSize: 16, color: '#8B8680', marginTop: 16 },
  emptySubText: { fontSize: 13, color: '#B5ADA5', marginTop: 8 },
});
