import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  ActivityIndicator,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import { useSafeRouter, useSafeSearchParams } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';

const API_BASE = `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1`;
const SCREEN_WIDTH = Dimensions.get('window').width;
const GRID_GAP = 4;
const PHOTO_SIZE = (SCREEN_WIDTH - GRID_GAP * 4) / 3;

interface SharedPhoto {
  id: number;
  image_url: string;
  thumbnail_url: string;
}

export default function ShareViewScreen() {
  const router = useSafeRouter();
  const { token } = useSafeSearchParams<{ token: string }>();
  const [photos, setPhotos] = useState<SharedPhoto[]>([]);
  const [shareInfo, setShareInfo] = useState<{ style_name: string; category_name: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useFocusEffect(
    useCallback(() => {
      const fetchShareData = async () => {
        try {
          /**
           * 服务端文件：server/src/routes/shares.ts
           * 接口：GET /api/v1/shares/:token
           * Path 参数：token: string
           */
          const response = await fetch(`${API_BASE}/shares/${token}`);
          if (!response.ok) {
            const data = await response.json();
            setError(data.error || '分享链接无效或已过期');
            return;
          }
          const data = await response.json();
          setPhotos(data.photos);
          setShareInfo({
            style_name: data.style_name,
            category_name: data.category_name,
          });
        } catch (err) {
          setError('加载失败，请稍后重试');
        } finally {
          setLoading(false);
        }
      };
      fetchShareData();
    }, [token])
  );

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  if (error) {
    return (
      <Screen>
        <View style={styles.errorContainer}>
          <FontAwesome6 name="link-slash" size={48} color="#D45D5D" />
          <Text style={styles.errorText}>{error}</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.canGoBack() ? router.back() : router.replace('/')} style={styles.backButton}>
          <FontAwesome6 name="chevron-left" size={20} color="#2C2420" />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={styles.headerTitle} numberOfLines={1}>{shareInfo?.style_name}</Text>
          <Text style={styles.headerSubtitle}>{shareInfo?.category_name}</Text>
        </View>
        <View style={styles.readonlyBadge}>
          <FontAwesome6 name="eye" size={12} color="#8B8680" />
          <Text style={styles.readonlyText}>只读</Text>
        </View>
      </View>

      {photos.length === 0 ? (
        <View style={styles.emptyContainer}>
          <FontAwesome6 name="images" size={48} color="#B5ADA5" />
          <Text style={styles.emptySubText}>该分享暂无照片</Text>
        </View>
      ) : (
        <FlatList
          data={photos}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.photoItem}
              onPress={() => router.push('/photo-fullscreen', { imageUrl: item.image_url })}
            >
              <Image source={{ uri: item.thumbnail_url || item.image_url }} style={styles.photo} />
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id.toString()}
          numColumns={3}
          contentContainerStyle={styles.gridContent}
          columnWrapperStyle={styles.gridRow}
          showsVerticalScrollIndicator={false}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  errorText: { fontSize: 15, color: '#D45D5D', marginTop: 16, textAlign: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  backButton: { width: 36, height: 36, justifyContent: 'center', alignItems: 'center' },
  headerCenter: { flex: 1, marginLeft: 8 },
  headerTitle: { fontSize: 20, fontWeight: '700', color: '#2C2420' },
  headerSubtitle: { fontSize: 12, color: '#8B8680', marginTop: 2 },
  readonlyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#F5F0EB',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  readonlyText: { fontSize: 12, color: '#8B8680' },
  gridContent: { paddingHorizontal: 2, paddingTop: 8 },
  gridRow: { justifyContent: 'flex-start', marginBottom: 2 },
  photoItem: {
    width: PHOTO_SIZE,
    marginHorizontal: GRID_GAP / 2,
    marginBottom: GRID_GAP,
  },
  photo: {
    width: PHOTO_SIZE,
    height: PHOTO_SIZE,
    borderRadius: 8,
    backgroundColor: '#F5F0EB',
  },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  emptySubText: { fontSize: 13, color: '#B5ADA5', marginTop: 8 },
});
