import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  Modal,
  TextInput,
  Platform,
  Dimensions,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Image,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { useSafeSearchParams } from '@/hooks/useSafeRouter';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { createFormDataFile } from '@/utils';
import * as Clipboard from 'expo-clipboard';

const API_BASE = `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1`;
const { width: SCREEN_WIDTH } = Dimensions.get('window');
const GRID_GAP = 2;
const PHOTO_SIZE = (SCREEN_WIDTH - GRID_GAP * 4) / 3;

interface Photo {
  id: number;
  image_url: string;
  thumbnail_url: string;
  note: string | null;
  created_at: string;
}

export default function PhotosScreen() {
  const router = useSafeRouter();
  const { styleId, styleName } = useSafeSearchParams<{ styleId: number; styleName: string }>();
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareLink, setShareLink] = useState('');
  // 刷新标记：只在上传/删除后才需要刷新
  const needsRefreshRef = useRef(true);

  const fetchPhotos = useCallback(async () => {
    try {
      const response = await fetch(`${API_BASE}/styles/${styleId}/photos?limit=100`);
      if (response.ok) {
        const data = await response.json();
        // Handle paginated response format
        setPhotos(data.photos || data);
      }
    } catch (error) {
      console.error('Failed to fetch photos:', error);
    } finally {
      setLoading(false);
    }
  }, [styleId]);

  // 只在需要时刷新（首次加载、上传、删除后）
  useFocusEffect(
    useCallback(() => {
      if (needsRefreshRef.current) {
        fetchPhotos();
        needsRefreshRef.current = false;
      }
    }, [fetchPhotos])
  );

  const handlePickImage = async () => {
    // Web 和移动端都使用 ImagePicker
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled && result.assets.length > 0) {
      await uploadPhotos(result.assets);
    }
  };

  const uploadPhotos = async (assets?: ImagePicker.ImagePickerAsset[]) => {
    if (!assets || assets.length === 0) return;

    if (!styleId) {
      Alert.alert('错误', '未找到风格信息，请返回重试');
      return;
    }

    setUploading(true);
    const maxRetries = 3;
    const failedUploads: { asset: ImagePicker.ImagePickerAsset; error: string }[] = [];

    try {
      for (const asset of assets) {
        let success = false;
        let lastError = '';

        for (let attempt = 1; attempt <= maxRetries; attempt++) {
          try {
            const formData = new FormData();
            const file = await createFormDataFile(asset.uri, `photo_${Date.now()}.jpg`, 'image/jpeg');
            formData.append('image', file as unknown as Blob);
            formData.append('style_id', String(styleId));

            const response = await fetch(`${API_BASE}/photos/upload`, {
              method: 'POST',
              body: formData,
            });

            if (response.ok) {
              success = true;
              break;
            } else {
              const errorData = await response.json().catch(() => ({ error: '上传失败' }));
              lastError = errorData.error || `HTTP ${response.status}`;
            }
          } catch (err) {
            lastError = err instanceof Error ? err.message : '网络错误';
          }

          // Wait before retry (exponential backoff)
          if (attempt < maxRetries) {
            await new Promise((resolve) => setTimeout(resolve, attempt * 1000));
          }
        }

        if (!success) {
          failedUploads.push({ asset, error: lastError });
        }
      }

      needsRefreshRef.current = true;
      fetchPhotos();

      // Show result summary
      if (failedUploads.length > 0) {
        alert(`上传完成：${assets.length - failedUploads.length} 张成功，${failedUploads.length} 张失败`);
      }
    } catch (error) {
      console.error('Upload failed:', error);
      alert('上传失败，请重试');
    } finally {
      setUploading(false);
    }
  };

  const handleUpdateNote = async (photoId: number, note: string) => {
    try {
      await fetch(`${API_BASE}/photos/${photoId}/note`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ note }),
      });
      setPhotos(prev => prev.map(p => (p.id === photoId ? { ...p, note } : p)));
    } catch (error) {
      console.error('Failed to update note:', error);
    }
  };

  const handleToggleSelect = (photoId: number) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(photoId)) {
        newSet.delete(photoId);
      } else {
        newSet.add(photoId);
      }
      return newSet;
    });
  };

  const handleExitEditMode = () => {
    setEditMode(false);
    setSelectedIds(new Set());
  };

  const handleDeleteSelected = async () => {
    setShowDeleteConfirm(false);
    try {
      for (const id of selectedIds) {
        await fetch(`${API_BASE}/photos/${id}`, { method: 'DELETE' });
      }
      needsRefreshRef.current = true;
      fetchPhotos();
      setEditMode(false);
      setSelectedIds(new Set());
    } catch (error) {
      console.error('Failed to delete photos:', error);
      alert('删除失败，请重试');
    }
  };

  const handleCreateShare = async () => {
    try {
      const response = await fetch(`${API_BASE}/shares`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ style_id: styleId, expired_days: 7 }),
      });
      if (response.ok) {
        const data = await response.json();
        const baseUrl = typeof window !== 'undefined' ? window.location.origin : process.env.EXPO_PUBLIC_BACKEND_BASE_URL || '';
        const link = `${baseUrl}/share-view?token=${data.share_token}`;
        setShareLink(link);
        setShowShareModal(true);
      }
    } catch (error) {
      console.error('Failed to create share:', error);
    }
  };

  const handleCopyLink = async () => {
    try {
      if (Platform.OS === 'web') {
        await navigator.clipboard.writeText(shareLink);
      } else {
        await Clipboard.setStringAsync(shareLink);
      }
      alert('链接已复制');
    } catch {
      alert('复制链接: ' + shareLink);
    }
  };

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        {editMode ? (
          <TouchableOpacity onPress={handleExitEditMode} style={styles.backButton}>
            <Text style={styles.cancelText}>取消</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))}
            style={styles.backButton}
          >
            <FontAwesome6 name="chevron-left" size={20} color="#2C2420" />
          </TouchableOpacity>
        )}
        <Text style={styles.headerTitle} numberOfLines={1}>
          {editMode ? `已选择 ${selectedIds.size} 张` : styleName || '照片'}
        </Text>
        <View style={styles.headerActions}>
          {editMode ? (
            <TouchableOpacity
              style={[styles.headerAction, styles.deleteButton, selectedIds.size === 0 && styles.headerActionDisabled]}
              onPress={() => selectedIds.size > 0 && setShowDeleteConfirm(true)}
              disabled={selectedIds.size === 0}
            >
              <FontAwesome6 name="trash" size={16} color="#D45D5D" />
            </TouchableOpacity>
          ) : (
            <>
              <TouchableOpacity style={[styles.headerAction, styles.editButton]} onPress={() => setEditMode(true)}>
                <Text style={styles.editButtonText}>编辑</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.headerAction, styles.shareButton]} onPress={handleCreateShare}>
                <FontAwesome6 name="share-nodes" size={16} color="#8B6F47" />
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>

      {photos.length === 0 ? (
        <View style={styles.emptyContainer}>
          <FontAwesome6 name="image" size={48} color="#D5CFC9" />
          <Text style={styles.emptyText}>暂无照片</Text>
          <Text style={styles.emptySubText}>点击 + 添加照片</Text>
        </View>
      ) : (
        <FlatList
          data={photos}
          keyExtractor={item => String(item.id)}
          numColumns={3}
          contentContainerStyle={styles.gridContent}
          columnWrapperStyle={styles.gridRow}
          renderItem={({ item }) => (
            <PhotoGridItem
              item={item}
              editMode={editMode}
              selected={selectedIds.has(item.id)}
              onToggleSelect={() => handleToggleSelect(item.id)}
              onFullScreen={(uri) => router.push('/photo-fullscreen', { imageUri: uri })}
              onUpdateNote={handleUpdateNote}
            />
          )}
        />
      )}

      {!editMode && (
        <TouchableOpacity
          style={[styles.addButton, { position: 'absolute', right: 20, bottom: 30 }]}
          onPress={handlePickImage}
          disabled={uploading}
        >
          {uploading ? (
            <ActivityIndicator color="#FFFFFF" size="small" />
          ) : (
            <FontAwesome6 name="plus" size={18} color="#FFFFFF" />
          )}
        </TouchableOpacity>
      )}

      {/* 删除确认弹窗 */}
      <Modal visible={showDeleteConfirm} transparent animationType="fade">
        <TouchableWithoutFeedback onPress={() => setShowDeleteConfirm(false)} disabled={Platform.OS === 'web'}>
          <View style={confirmStyles.overlay}>
            <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
              <TouchableWithoutFeedback onPress={Keyboard.dismiss} disabled={Platform.OS === 'web'}>
                <View style={confirmStyles.modal}>
                  <Text style={confirmStyles.title}>确认删除</Text>
                  <Text style={confirmStyles.message}>
                    确定删除选中的 {selectedIds.size} 张照片吗？
                  </Text>
                  <View style={confirmStyles.actions}>
                    <TouchableOpacity
                      style={[confirmStyles.btn, confirmStyles.cancelBtn]}
                      onPress={() => setShowDeleteConfirm(false)}
                    >
                      <Text style={confirmStyles.cancelText}>取消</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[confirmStyles.btn, confirmStyles.deleteBtn]}
                      onPress={handleDeleteSelected}
                    >
                      <Text style={confirmStyles.deleteText}>删除</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </TouchableWithoutFeedback>
            </KeyboardAvoidingView>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* 分享弹窗 */}
      <Modal visible={showShareModal} transparent animationType="slide">
        <View style={styles.shareOverlay}>
          <View style={styles.sharePanel}>
            <View style={styles.sharePanelHeader}>
              <Text style={styles.sharePanelTitle}>分享风格</Text>
              <TouchableOpacity onPress={() => setShowShareModal(false)}>
                <FontAwesome6 name="xmark" size={20} color="#8B8680" />
              </TouchableOpacity>
            </View>
            <View style={styles.shareLinkBox}>
              <Text style={styles.shareLinkText} numberOfLines={1}>
                {shareLink}
              </Text>
            </View>
            <View style={styles.shareActions}>
              <TouchableOpacity style={styles.shareActionBtn} onPress={handleCopyLink}>
                <FontAwesome6 name="copy" size={16} color="#8B6F47" />
                <Text style={styles.shareActionText}>复制链接</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.shareExpiry}>链接有效期 7 天</Text>
          </View>
        </View>
      </Modal>
    </Screen>
  );
}

function PhotoGridItem({
  item,
  editMode,
  selected,
  onToggleSelect,
  onFullScreen,
  onUpdateNote,
}: {
  item: Photo;
  editMode: boolean;
  selected: boolean;
  onToggleSelect: () => void;
  onFullScreen: (uri: string) => void;
  onUpdateNote: (id: number, note: string) => void;
}) {
  const [noteText, setNoteText] = useState(item.note);

  const handlePress = () => {
    if (editMode) {
      onToggleSelect();
    } else {
      onFullScreen(item.image_url);
    }
  };

  return (
    <View style={gridStyles.photoItem}>
      <TouchableOpacity onPress={handlePress}>
        <Image
          source={{ uri: item.thumbnail_url || item.image_url }}
          style={gridStyles.photo}
          resizeMode="cover"
        />
        {editMode && (
          <View style={[gridStyles.selectOverlay, selected && gridStyles.selectOverlayActive]}>
            <View style={[gridStyles.checkbox, selected && gridStyles.checkboxActive]}>
              {selected && <FontAwesome6 name="check" size={12} color="#FFFFFF" />}
            </View>
          </View>
        )}
      </TouchableOpacity>
      {!editMode && (
        <TextInput
          style={gridStyles.noteInput}
          placeholder="备注..."
          placeholderTextColor="#B5ADA5"
          value={noteText}
          multiline
          onBlur={() => {
            if (noteText !== item.note) {
              onUpdateNote(item.id, noteText);
            }
          }}
          onChangeText={setNoteText}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  backButton: { width: 44, height: 36, justifyContent: 'center', alignItems: 'center' },
  cancelText: { fontSize: 16, color: '#8B6F47' },
  headerTitle: { flex: 1, fontSize: 22, fontWeight: '700', color: '#2C2420', marginLeft: 8 },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerAction: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  headerActionDisabled: { opacity: 0.4 },
  shareButton: {
    backgroundColor: 'rgba(139, 111, 71, 0.1)',
  },
  editButton: {
    backgroundColor: 'rgba(139, 111, 71, 0.1)',
    width: 'auto',
    paddingHorizontal: 12,
  },
  editButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#8B6F47',
  },
  deleteButton: {
    backgroundColor: 'rgba(212, 93, 93, 0.1)',
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#8B6F47',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButtonDisabled: { opacity: 0.6 },
  gridContent: { paddingHorizontal: 2, paddingTop: 8 },
  gridRow: { justifyContent: 'flex-start', marginBottom: 2 },
  emptyContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 100 },
  emptyText: { fontSize: 16, color: '#8B8680', marginTop: 16 },
  emptySubText: { fontSize: 13, color: '#B5ADA5', marginTop: 8 },
  shareOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'flex-end',
  },
  sharePanel: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 34,
  },
  sharePanelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sharePanelTitle: { fontSize: 18, fontWeight: '600', color: '#2C2420' },
  shareLinkBox: {
    backgroundColor: '#F5F0EB',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginBottom: 16,
  },
  shareLinkText: { fontSize: 13, color: '#8B8680' },
  shareActions: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 24,
    marginBottom: 16,
  },
  shareActionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: 'rgba(139, 111, 71, 0.08)',
    borderRadius: 20,
  },
  shareActionText: { fontSize: 14, fontWeight: '500', color: '#8B6F47' },
  shareExpiry: { textAlign: 'center', fontSize: 12, color: '#B5ADA5' },
});

// 删除确认弹窗样式
const confirmStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modal: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 320,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2C2420',
    textAlign: 'center',
    marginBottom: 8,
  },
  message: {
    fontSize: 15,
    color: '#8B8680',
    textAlign: 'center',
    marginBottom: 20,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  btn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelBtn: {
    backgroundColor: '#F5F0EB',
  },
  cancelText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#8B8680',
  },
  deleteBtn: {
    backgroundColor: '#D45D5D',
  },
  deleteText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});

const gridStyles = StyleSheet.create({
  photoItem: {
    width: PHOTO_SIZE,
    marginRight: GRID_GAP,
  },
  photo: {
    width: PHOTO_SIZE,
    height: PHOTO_SIZE,
    borderRadius: 4,
  },
  selectOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 4,
  },
  selectOverlayActive: {
    backgroundColor: 'rgba(139, 111, 71, 0.2)',
  },
  checkbox: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: '#FFFFFF',
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxActive: {
    backgroundColor: '#8B6F47',
  },
  noteInput: {
    marginTop: 4,
    fontSize: 11,
    color: '#666666',
    borderWidth: 1,
    borderColor: '#E0D8D0',
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 4,
    minHeight: 28,
    maxHeight: 56,
    backgroundColor: '#FFFFFF',
  },
});
