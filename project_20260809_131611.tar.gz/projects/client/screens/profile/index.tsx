import { useState, useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Screen } from '@/components/Screen';
import { FontAwesome6 } from '@expo/vector-icons';
import { useFocusEffect } from 'expo-router';

const API_BASE = `${process.env.EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1`;

interface ShareItem {
  id: number;
  share_token: string;
  style_name: string;
  category_name: string;
  created_at: string;
  expired_at: string;
  is_expired: boolean;
}

export default function ProfileScreen() {
  const [shares, setShares] = useState<ShareItem[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchShares = useCallback(async () => {
    try {
      /**
       * 服务端文件：server/src/routes/shares.ts
       * 接口：GET /api/v1/shares
       * 无参数
       */
      const response = await fetch(`${API_BASE}/shares`);
      const data = await response.json();
      setShares(data);
    } catch (err) {
      console.error('Failed to fetch shares:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      fetchShares();
    }, [fetchShares])
  );

  const handleCancelShare = (share: ShareItem) => {
    Alert.alert('取消分享', `确定取消"${share.style_name}"的分享吗？`, [
      { text: '取消', style: 'cancel' },
      {
        text: '确定',
        style: 'destructive',
        onPress: async () => {
          try {
            /**
             * 服务端文件：server/src/routes/shares.ts
             * 接口：DELETE /api/v1/shares/:id
             * Path 参数：id: number
             */
            await fetch(`${API_BASE}/shares/${share.id}`, { method: 'DELETE' });
            fetchShares();
          } catch (err) {
            Alert.alert('错误', '操作失败');
          }
        },
      },
    ]);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return `${date.getFullYear()}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <Screen>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B6F47" />
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>我的</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>分享管理</Text>
        {shares.length === 0 ? (
          <View style={styles.emptyContainer}>
            <FontAwesome6 name="share-nodes" size={36} color="#B5ADA5" />
            <Text style={styles.emptyText}>暂无分享记录</Text>
          </View>
        ) : (
          <FlatList
            data={shares}
            renderItem={({ item }) => (
              <View style={styles.shareRow}>
                <View style={styles.shareInfo}>
                  <Text style={styles.shareName}>{item.style_name}</Text>
                  <Text style={styles.shareMeta}>
                    {item.category_name} · 创建于 {formatDate(item.created_at)}
                  </Text>
                  <Text style={styles.shareExpiry}>
                    {item.is_expired ? '已过期' : `有效期至 ${formatDate(item.expired_at)}`}
                  </Text>
                </View>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => handleCancelShare(item)}
                >
                  <FontAwesome6 name="trash" size={16} color="#D45D5D" />
                </TouchableOpacity>
              </View>
            )}
            keyExtractor={(item) => item.id.toString()}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 28, fontWeight: '700', color: '#2C2420' },
  section: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2C2420',
    marginBottom: 12,
    marginLeft: 4,
  },
  shareRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    shadowColor: 'rgba(139, 111, 71, 0.06)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 2,
  },
  shareInfo: { flex: 1 },
  shareName: { fontSize: 15, fontWeight: '600', color: '#2C2420', marginBottom: 4 },
  shareMeta: { fontSize: 12, color: '#8B8680', marginBottom: 2 },
  shareExpiry: { fontSize: 11, color: '#B5ADA5' },
  cancelButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(212, 93, 93, 0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: { alignItems: 'center', paddingTop: 40 },
  emptyText: { fontSize: 14, color: '#8B8680', marginTop: 12 },
});
