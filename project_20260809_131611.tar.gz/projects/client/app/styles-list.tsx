export { default } from "@/screens/styles-list";
