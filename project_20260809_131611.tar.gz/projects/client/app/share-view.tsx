export { default } from "@/screens/share-view";
