export { default } from "@/screens/photo-fullscreen";
