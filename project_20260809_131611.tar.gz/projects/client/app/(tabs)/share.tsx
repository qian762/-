export { default } from "@/screens/share-center";
