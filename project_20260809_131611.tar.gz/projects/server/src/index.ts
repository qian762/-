import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import categoriesRouter from "./routes/categories.js";
import stylesRouter from "./routes/styles.js";
import stylePhotosRouter from "./routes/style-photos.js";
import photoManageRouter from "./routes/photo-manage.js";
import sharesRouter from "./routes/shares.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// 托管前端静态文件（Web 部署）
const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));

// Health check
app.get('/api/v1/health', (req, res) => {
  console.log('Health check success');
  res.status(200).json({ status: 'ok' });
});

// API Routes (static before dynamic)
app.use('/api/v1/categories', categoriesRouter);
app.use('/api/v1/styles', stylesRouter);
app.use('/api/v1/styles/:styleId/photos', stylePhotosRouter);
app.use('/api/v1/photos', photoManageRouter);
app.use('/api/v1/shares', sharesRouter);

// SPA fallback - 所有非 API 请求返回 index.html
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api/')) {
    res.sendFile(path.join(publicPath, 'index.html'));
  }
});

// Multer error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
    res.status(413).json({ error: '文件大小超过限制（最大 10MB）' });
    return;
  }
  next(err);
});

// Global error handling
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Error:', err.message);
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// Vercel Serverless 兼容：导出 app
export default app;

// 本地开发/传统部署：监听端口
if (process.env.NODE_ENV !== 'production' || !process.env.VERCEL) {
  app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}/`);
  });
}
