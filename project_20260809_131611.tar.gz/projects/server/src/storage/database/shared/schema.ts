import { pgTable, serial, varchar, text, integer, boolean, timestamp, index } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";


export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const categories = pgTable(
  "categories",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 100 }).notNull(),
    icon: varchar("icon", { length: 50 }).notNull().default("Home"),
    sort_order: integer("sort_order").notNull().default(0),
    is_preset: boolean("is_preset").notNull().default(false),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("categories_sort_order_idx").on(table.sort_order),
  ]
);

export const styles = pgTable(
  "styles",
  {
    id: serial("id").primaryKey(),
    category_id: integer("category_id").notNull().references(() => categories.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 100 }).notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("styles_category_id_idx").on(table.category_id),
  ]
);

export const photos = pgTable(
  "photos",
  {
    id: serial("id").primaryKey(),
    style_id: integer("style_id").notNull().references(() => styles.id, { onDelete: "cascade" }),
    image_url: text("image_url").notNull(),
    image_key: varchar("image_key", { length: 500 }).notNull(),
    thumbnail_key: varchar("thumbnail_key", { length: 500 }),
    note: text("note"),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("photos_style_id_idx").on(table.style_id),
  ]
);

export const shares = pgTable(
  "shares",
  {
    id: serial("id").primaryKey(),
    share_token: varchar("share_token", { length: 64 }).notNull().unique(),
    style_id: integer("style_id").notNull().references(() => styles.id, { onDelete: "cascade" }),
    expired_at: timestamp("expired_at", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("shares_share_token_idx").on(table.share_token),
    index("shares_style_id_idx").on(table.style_id),
  ]
);
