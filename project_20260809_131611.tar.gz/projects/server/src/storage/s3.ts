import { S3Storage } from 'coze-coding-dev-sdk';

const storage = new S3Storage({
  endpointUrl: process.env.COZE_BUCKET_ENDPOINT_URL,
  accessKey: '',
  secretKey: '',
  bucketName: process.env.COZE_BUCKET_NAME,
  region: 'cn-beijing',
});

export async function uploadImage(buffer: Buffer, fileName: string, contentType: string): Promise<{ key: string; url: string }> {
  const key = await storage.uploadFile({
    fileContent: buffer,
    fileName: `furniture/${fileName}`,
    contentType,
  });

  const url = await storage.generatePresignedUrl({
    key,
    expireTime: 2592000, // 30 days
  });

  return { key, url };
}

export async function deleteImage(key: string): Promise<boolean> {
  return storage.deleteFile({ fileKey: key });
}

export async function getImageUrl(key: string): Promise<string> {
  return storage.generatePresignedUrl({
    key,
    expireTime: 2592000, // 30 days
  });
}
