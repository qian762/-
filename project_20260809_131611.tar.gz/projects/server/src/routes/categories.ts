import { Router } from 'express';
import { getSupabaseClient } from '../storage/database/supabase-client.js';
import { deleteImage } from '../storage/s3.js';

const router = Router();
let client: ReturnType<typeof getSupabaseClient> | null = null;
const getClient = () => client ?? (client = getSupabaseClient());

// GET /api/v1/categories - List all categories
router.get('/', async (req, res, next) => {
  try {
    const { data, error } = await getClient()
      .from('categories')
      .select('*')
      .order('sort_order', { ascending: true });
    if (error) throw new Error(error.message);
    res.json(data);
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/categories/:categoryId/styles - List styles for a category
router.get('/:categoryId/styles', async (req, res, next) => {
  try {
    const { categoryId } = req.params;
    const numCategoryId = parseInt(categoryId, 10);
    if (isNaN(numCategoryId)) {
      res.status(400).json({ error: 'Invalid category id' });
      return;
    }
    const { data, error } = await getClient()
      .from('styles')
      .select('id, name, created_at, photos(count)')
      .eq('category_id', numCategoryId)
      .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);
    // Transform count from array to number
    const styles = (data || []).map((s: any) => ({
      id: s.id,
      name: s.name,
      created_at: s.created_at,
      photo_count: s.photos?.[0]?.count ?? 0,
    }));
    res.json(styles);
  } catch (err) {
    next(err);
  }
});

// POST /api/v1/categories - Create a category
router.post('/', async (req, res, next) => {
  try {
    const { name, icon } = req.body;
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      res.status(400).json({ error: 'name is required' });
      return;
    }
    if (name.length > 50) {
      res.status(400).json({ error: 'name must be 50 characters or less' });
      return;
    }
    const { data, error } = await getClient()
      .from('categories')
      .insert({ name: name.trim(), icon: icon || null })
      .select()
      .single();
    if (error) throw new Error(error.message);
    res.status(201).json(data);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/categories/:id - Delete a category (cascades to styles and photos)
router.delete('/:id', async (req, res, next) => {
  try {
    const id = req.params.id;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      res.status(400).json({ error: 'Invalid id' });
      return;
    }

    // 先获取该分类下所有风格的照片，用于清理 S3 文件
    const { data: styles } = await getClient()
      .from('styles')
      .select('id')
      .eq('category_id', numId);

    let allPhotos: { image_key: string | null; thumbnail_key: string | null }[] = [];
    if (styles && styles.length > 0) {
      const styleIds = styles.map((s) => s.id);
      const { data: photos } = await getClient()
        .from('photos')
        .select('image_key, thumbnail_key')
        .in('style_id', styleIds);
      allPhotos = photos || [];
    }

    // 删除数据库记录
    const { data, error } = await getClient()
      .from('categories')
      .delete()
      .eq('id', numId)
      .select()
      .single();
    if (error) throw new Error(error.message);

    // 清理 S3 文件（异步执行，不阻塞响应）
    if (allPhotos.length > 0) {
      setImmediate(async () => {
        for (const photo of allPhotos) {
          try {
            if (photo.image_key) await deleteImage(photo.image_key);
            if (photo.thumbnail_key) await deleteImage(photo.thumbnail_key);
          } catch (err) {
            console.error('Failed to delete photo from S3:', err);
          }
        }
      });
    }

    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

export default router;
