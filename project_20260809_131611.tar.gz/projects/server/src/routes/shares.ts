import { Router } from 'express';
import crypto from 'crypto';
import dayjs from 'dayjs';
import { getSupabaseClient } from '../storage/database/supabase-client.js';
import { getImageUrl } from '../storage/s3.js';

const router = Router();
let client: ReturnType<typeof getSupabaseClient> | null = null;
const getClient = () => client ?? (client = getSupabaseClient());

// POST /api/v1/shares - Create a share link
router.post('/', async (req, res, next) => {
  try {
    const { style_id, expired_days } = req.body;
    const numStyleId = parseInt(style_id, 10);
    if (isNaN(numStyleId)) {
      res.status(400).json({ error: 'Invalid style_id' });
      return;
    }

    const shareToken = crypto.randomUUID().replace(/-/g, '');
    const days = expired_days || 7;
    const expiredAt = dayjs().add(days, 'day').toISOString();

    // 验证 style_id 是否存在
    const { data: style } = await getClient()
      .from('styles')
      .select('id')
      .eq('id', numStyleId)
      .single();
    if (!style) {
      res.status(404).json({ error: 'Style not found' });
      return;
    }

    const { data, error } = await getClient()
      .from('shares')
      .insert({
        share_token: shareToken,
        style_id: numStyleId,
        expired_at: expiredAt,
      })
      .select()
      .single();
    if (error) throw new Error(error.message);
    res.status(201).json(data);
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/shares - Get all shares
router.get('/', async (req, res, next) => {
  try {
    const { data, error } = await getClient()
      .from('shares')
      .select('id, share_token, style_id, expired_at, created_at')
      .order('created_at', { ascending: false });
    if (error) throw new Error(error.message);

    const sharesWithInfo = await Promise.all(
      (data || []).map(async (share) => {
        const { data: style } = await getClient()
          .from('styles')
          .select('id, name, category_id')
          .eq('id', share.style_id)
          .single();

        let categoryName = '';
        if (style) {
          const { data: category } = await getClient()
            .from('categories')
            .select('name')
            .eq('id', style.category_id)
            .single();
          categoryName = category?.name || '';
        }

        // Get first photo as cover
        const { data: firstPhoto } = await getClient()
          .from('photos')
          .select('image_key, thumbnail_key')
          .eq('style_id', share.style_id)
          .limit(1)
          .single();

        // Get photo count
        const { count } = await getClient()
          .from('photos')
          .select('*', { count: 'exact', head: true })
          .eq('style_id', share.style_id);

        const isExpired = share.expired_at ? dayjs().isAfter(dayjs(share.expired_at)) : false;

        return {
          id: share.id,
          share_token: share.share_token,
          style_name: style?.name || 'Unknown',
          category_name: categoryName,
          created_at: share.created_at,
          expired_at: share.expired_at,
          is_expired: isExpired,
          photo_count: count || 0,
          cover_url: firstPhoto?.thumbnail_key ? await getImageUrl(firstPhoto.thumbnail_key) : (firstPhoto?.image_key ? await getImageUrl(firstPhoto.image_key) : null),
        };
      })
    );

    res.json(sharesWithInfo);
  } catch (err) {
    next(err);
  }
});

// GET /api/v1/shares/:token - Get share details (public)
router.get('/:token', async (req, res, next) => {
  try {
    const token = req.params.token;

    const { data: share, error: shareError } = await getClient()
      .from('shares')
      .select('id, style_id, expired_at')
      .eq('share_token', token)
      .single();

    if (shareError || !share) {
      res.status(404).json({ error: '分享链接不存在' });
      return;
    }

    // Check expiration
    if (share.expired_at && dayjs().isAfter(dayjs(share.expired_at))) {
      res.status(410).json({ error: '分享链接已过期' });
      return;
    }

    // Get style and category info
    const { data: style } = await getClient()
      .from('styles')
      .select('name, category_id')
      .eq('id', share.style_id)
      .single();

    let categoryName = '';
    if (style) {
      const { data: category } = await getClient()
        .from('categories')
        .select('name')
        .eq('id', style.category_id)
        .single();
      categoryName = category?.name || '';
    }

    // Get photos (no notes for shared view)
    const { data: photos } = await getClient()
      .from('photos')
      .select('id, image_key, thumbnail_key')
      .eq('style_id', share.style_id)
      .order('created_at', { ascending: false });

    const photosWithUrls = await Promise.all(
      (photos || []).map(async (p) => ({
        id: p.id,
        thumbnail_url: p.thumbnail_key ? await getImageUrl(p.thumbnail_key) : await getImageUrl(p.image_key),
        image_url: await getImageUrl(p.image_key),
      }))
    );

    res.json({
      style_name: style?.name || 'Unknown',
      category_name: categoryName,
      photos: photosWithUrls,
    });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/shares/:id - Cancel a share
router.delete('/:id', async (req, res, next) => {
  try {
    const id = req.params.id;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      res.status(400).json({ error: 'Invalid id' });
      return;
    }

    const { error } = await getClient()
      .from('shares')
      .delete()
      .eq('id', numId);
    if (error) throw new Error(error.message);

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

export default router;
