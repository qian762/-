import { Router } from 'express';
import { getSupabaseClient } from '../storage/database/supabase-client.js';
import { deleteImage } from '../storage/s3.js';

const router = Router();
let client: ReturnType<typeof getSupabaseClient> | null = null;
const getClient = () => client ?? (client = getSupabaseClient());

// POST /api/v1/styles - Create a style
router.post('/', async (req, res, next) => {
  try {
    const { category_id, name } = req.body;
    const numCategoryId = parseInt(category_id, 10);
    if (isNaN(numCategoryId)) {
      res.status(400).json({ error: 'Invalid category_id' });
      return;
    }
    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      res.status(400).json({ error: 'name is required' });
      return;
    }
    if (name.length > 50) {
      res.status(400).json({ error: 'name must be 50 characters or less' });
      return;
    }

    // 验证 category_id 是否存在
    const { data: category } = await getClient()
      .from('categories')
      .select('id')
      .eq('id', numCategoryId)
      .single();
    if (!category) {
      res.status(404).json({ error: 'Category not found' });
      return;
    }

    const { data, error } = await getClient()
      .from('styles')
      .insert({ category_id: numCategoryId, name: name.trim() })
      .select()
      .single();
    if (error) throw new Error(error.message);
    res.status(201).json(data);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/styles/:id - Delete a style (cascades to photos)
router.delete('/:id', async (req, res, next) => {
  try {
    const id = req.params.id;
    const numId = parseInt(id, 10);
    if (isNaN(numId)) {
      res.status(400).json({ error: 'Invalid id' });
      return;
    }

    // 先获取该风格下的所有照片，用于清理 S3 文件
    const { data: photos } = await getClient()
      .from('photos')
      .select('image_key, thumbnail_key')
      .eq('style_id', numId);

    // 删除数据库记录
    const { data, error } = await getClient()
      .from('styles')
      .delete()
      .eq('id', numId)
      .select()
      .single();
    if (error) throw new Error(error.message);

    // 清理 S3 文件（异步执行，不阻塞响应）
    if (photos && photos.length > 0) {
      setImmediate(async () => {
        for (const photo of photos) {
          try {
            if (photo.image_key) await deleteImage(photo.image_key);
            if (photo.thumbnail_key) await deleteImage(photo.thumbnail_key);
          } catch (err) {
            console.error('Failed to delete photo from S3:', err);
          }
        }
      });
    }

    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

export default router;
