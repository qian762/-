import { Router } from 'express';
import multer from 'multer';
import sharp from 'sharp';
import { getSupabaseClient } from '../storage/database/supabase-client.js';
import { uploadImage, deleteImage, getImageUrl } from '../storage/s3.js';

const router = Router();
let client: ReturnType<typeof getSupabaseClient> | null = null;
const getClient = () => client ?? (client = getSupabaseClient());

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/heic', 'image/heif'];

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (_req, file, cb) => {
    if (ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only image files (JPEG, PNG, GIF, WebP, HEIC) are allowed'));
    }
  },
});

// POST /api/v1/photos/upload - Upload a photo
router.post('/upload', (req, res, next) => {
  upload.single('image')(req, res, (err) => {
    if (err) {
      if (err.message.includes('Only image files')) {
        res.status(400).json({ error: err.message });
      } else if (err.code === 'LIMIT_FILE_SIZE') {
        res.status(400).json({ error: 'File size exceeds 10MB limit' });
      } else {
        res.status(400).json({ error: 'Upload error: ' + err.message });
      }
      return;
    }
    next();
  });
}, async (req, res) => {
  try {
    const file = req.file;
    const styleId = parseInt(req.body.style_id, 10);

    if (!file) {
      res.status(400).json({ error: 'No file uploaded' });
      return;
    }
    if (isNaN(styleId)) {
      res.status(400).json({ error: 'Invalid style_id' });
      return;
    }

    // 验证 style_id 是否存在
    const { data: style } = await getClient()
      .from('styles')
      .select('id')
      .eq('id', styleId)
      .single();
    if (!style) {
      res.status(404).json({ error: 'Style not found' });
      return;
    }

    const ext = file.originalname.split('.').pop() || 'jpg';
    const baseName = `photo_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const fileName = `${baseName}.${ext}`;

    // Upload original image
    const { key, url } = await uploadImage(file.buffer, fileName, file.mimetype);

    // Generate thumbnail (max 300px width, quality 70)
    let thumbnailKey: string | null = null;
    try {
      const thumbBuffer = await sharp(file.buffer)
        .resize(300, 300, { fit: 'inside', withoutEnlargement: true })
        .jpeg({ quality: 70 })
        .toBuffer();
      const thumbFileName = `${baseName}_thumb.jpg`;
      const thumbResult = await uploadImage(thumbBuffer, thumbFileName, 'image/jpeg');
      thumbnailKey = thumbResult.key;
    } catch (thumbErr) {
      console.warn('[PHOTO] Thumbnail generation failed:', thumbErr);
      // Continue without thumbnail
    }

    const { data, error } = await getClient()
      .from('photos')
      .insert({
        style_id: styleId,
        image_url: url,
        image_key: key,
        thumbnail_key: thumbnailKey,
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    res.status(201).json(data);
  } catch (err) {
    next(err);
  }
});

// PUT /api/v1/photos/:id/note - Update photo note
router.put('/:id/note', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { note } = req.body;

    if (isNaN(id)) {
      res.status(400).json({ error: 'Invalid photo id' });
      return;
    }

    const { data, error } = await getClient()
      .from('photos')
      .update({ note })
      .eq('id', id)
      .select()
      .single();

    if (error) throw new Error(error.message);
    res.json(data);
  } catch (err) {
    next(err);
  }
});

// DELETE /api/v1/photos/:id - Delete a photo
router.delete('/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);

    if (isNaN(id)) {
      res.status(400).json({ error: 'Invalid photo id' });
      return;
    }

    // Get photo to find storage key
    const { data: photo, error: fetchError } = await getClient()
      .from('photos')
      .select('image_key, thumbnail_key')
      .eq('id', id)
      .single();

    if (fetchError) throw new Error(fetchError.message);

    if (photo) {
      // Delete from storage
      await deleteImage(photo.image_key);
      if (photo.thumbnail_key) {
        await deleteImage(photo.thumbnail_key);
      }

      // Delete from database
      const { error: deleteError } = await getClient()
        .from('photos')
        .delete()
        .eq('id', id);

      if (deleteError) throw new Error(deleteError.message);
    }

    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

export default router;
