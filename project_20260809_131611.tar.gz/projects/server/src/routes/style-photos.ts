import { Router } from 'express';
import { getSupabaseClient } from '../storage/database/supabase-client.js';
import { getImageUrl } from '../storage/s3.js';

const router = Router({ mergeParams: true });
let client: ReturnType<typeof getSupabaseClient> | null = null;
const getClient = () => client ?? (client = getSupabaseClient());

// GET /api/v1/styles/:styleId/photos - Get photos for a style (with pagination)
router.get('/', async (req: any, res, next) => {
  try {
    const styleId = req.params.styleId;
    const numStyleId = parseInt(styleId, 10);
    if (isNaN(numStyleId)) {
      res.status(400).json({ error: 'Invalid styleId' });
      return;
    }

    // Pagination parameters
    const page = Math.max(1, parseInt(req.query.page as string, 10) || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string, 10) || 50));
    const offset = (page - 1) * limit;

    // Get total count
    const { count, error: countError } = await getClient()
      .from('photos')
      .select('*', { count: 'exact', head: true })
      .eq('style_id', numStyleId);
    if (countError) throw new Error(countError.message);

    const { data, error } = await getClient()
      .from('photos')
      .select('id, style_id, image_key, thumbnail_key, note, created_at')
      .eq('style_id', numStyleId)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);
    if (error) throw new Error(error.message);

    // Generate signed URLs for each photo (thumbnail for grid, full for detail)
    const photosWithUrls = await Promise.all(
      (data || []).map(async (photo) => ({
        id: photo.id,
        style_id: photo.style_id,
        note: photo.note,
        created_at: photo.created_at,
        // thumbnail_url for grid view (small, fast loading)
        thumbnail_url: photo.thumbnail_key ? await getImageUrl(photo.thumbnail_key) : await getImageUrl(photo.image_key),
        // image_url for fullscreen view (original quality)
        image_url: await getImageUrl(photo.image_key),
      }))
    );

    res.json({
      photos: photosWithUrls,
      pagination: {
        page,
        limit,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / limit),
      },
    });
  } catch (err) {
    next(err);
  }
});

export default router;
